from typing import List, Set, Optional
from .models import FunctionDefinition
from .vocabulary import Vocabulary


class FunctionSelector:
    def __init__(self, model, vocabulary: Vocabulary,
                 functions: List[FunctionDefinition]):
        self.model = model
        self.vocab = vocabulary
        self.functions = functions

        self._tokenized_functions = self._tokenize_functions_names()

    def _tokenize_function_names(self) -> dict:
        tokenized = {}
        for fn in self.functions:
            tokens = self.model._encode(fn.fn_name).tolist()[0]
            tokenized[fn.fn_name] = tokens
        return tokenized
    
    def select_function(self, prompt: str) -> Optional[FunctionDefinition]:
        instruction = f"'{prompt}'\nfn_"

        instruction_ids = self.model_encode(instruction).tolist()[0]
		# model._encode() lo convierte a tensor([[4520, 4521, 4522, ..., 4523]])
        # .tolist() lo convierte en lista [[4520, 4521, 4522, ..., 4523]]
        # [0] obtiene la primera (y única) fila [4520, 4521, 4522, ..., 4523]
        generate_ids = []
        max_tokens = 20
        for step in range(max_tokens):
            valid_tokens = self._get_valid_function_tokens(generate_ids)
            if not valid_tokens:
                break

            full_input = instruction_ids + generate_ids
            try:
                logits = self.model.get_logits_from_input_ids(full_input)
            except Exception:
                break

            masked_logits = self._mask_logits(logits, valid_tokens)
            max_logit = max(masked_logits)
            if max_logit  == float('-inf'):
                break
            next_token = masked_logits.index(max_logit)
            generate_ids.append(next_token)

            generated_text = self.model._encode(generate_ids)
            full_name = "fn_" + generated_text.strip()
            for fn in self.functions:
                if fn.fn_name == full_name:
                    return fn
                
            if generate_ids:
                generated_text = self.model._decode(generate_ids).strip()
                full_name = "fn_" + generated_text
                for fn in self.functions:
                    if fn.fn_name.startswith(full_name):
                        return fn
            
            return None

    def _get_valid_function_tokens(self, generated_ids: List[int]) -> Set[int]:
        valid = set()

        for fn_name, fn_tokens in self._tokenize_function_names.items():
            fn_tokens_without_prefix = fn_tokens[1:] if len(fn_tokens) > 1 else fn_tokens
            if len(generated_ids) < len(fn_tokens_without_prefix):
                match = True
                for i, gen_id in enumerate(generated_ids):
                    if gen_id != fn_tokens_without_prefix[i]:
                        match = False
                        break
                    if match:
                        next_token_id = fn_tokens_without_prefix[len(generated_ids)]
                        valid.add(next_token_id)

        return valid
    
    def _mask_logits(self, logits: List[float], valid_tokens: Set[int]) -> List[float]:
        masked = logits.copy()
        for i in range(len(masked)):
            if i not in valid_tokens:
                masked[i] = float('-inf')
        return masked