import re
from typing import Dict, Any
from .models import FunctionDefinition


class ArgumentExtractor:
    @staticmethod
    def extract(prompt: str, function: FunctionDefinition) -> Dict[str, Any]:
        args = {}
        prompt_lower = prompt.lower()
        fn_name = function.fn_name

        if fn_name in ["fn_add_numbers", "fn_multiply_numbers"]:
            args = ArgumentExtractor._extract_binary_math(prompt, function)
        
        elif fn_name == "fn_get_square_root":
            args = ArgumentExtractor._extract_unary_math(prompt, function)

        elif fn_name == "fn_is_even":
            args = ArgumentExtractor._extract_is_even(prompt, function)
        
        elif fn_name == "fn_reverse_string":
            args = ArgumentExtractor._extract_string_arg(prompt, function, 's')
        
        elif fn_name == "fn_greet":
            args = ArgumentExtractor._extract_greet(prompt, function)
        
        elif fn_name == "fn_substitute_string_with_regex":
            args = ArgumentExtractor._extract_substitute(prompt, function)
        
        return args
    
    @staticmethod
    def _extract_binary_math(prompt: str, function: FunctionDefinition) -> Dict[str, Any]:
        numbers = re.findall(r'\b\d+(?:\.\d+)?\b', prompt)
        args = {}
    
        if len(numbers) >= 2:
            args["a"] = float(numbers[0])
            args["b"] = float(numbers[1])
        return args
    
    @staticmethod
    def _extract_unary_math(prompt: str, function: FunctionDefinition) -> Dict[str, Any]:
        numbers = re.findall(r'\b\d+(?:\.\d+)?\b', prompt)
        args = {}
    
        if numbers:
            args["a"] = float(numbers[0])
        return args
    
    @staticmethod
    def _extract_is_even(prompt: str, function: FunctionDefinition) -> Dict[str, Any]:
        numbers = re.findall(r'\b\d+\b', prompt)
        args = {}
    
        if numbers:
            args["n"] = int(numbers[0])
        return args
    
    @staticmethod
    def _extract_string_arg(prompt: str, function: FunctionDefinition, arg_name: str) -> Dict[str, Any]:
        args = {}
        # Try single quotes first
        match = re.search(r"'([^']*)'", prompt)
        if not match:
            # Try double quotes
            match = re.search(r'"([^"]*)"', prompt)
        if match:
            args[arg_name] = match.group(1)
            # match.group(0) = "'hello'"  (todo el match)
            # match.group(1) = "hello"    (solo lo capturado)
        return args
    
    @staticmethod
    def _extract_greet(prompt: str, function: FunctionDefinition) -> Dict[str, Any]:
        args = {}
        # Pattern: "Greet <name>"
        match = re.search(r'greet\s+(\w+)', prompt.lower())
        if match:
            args["name"] = match.group(1)
        return args
    
    @staticmethod
    def _extract_substitute(prompt: str, function: FunctionDefinition) -> Dict[str, Any]:
        args = {}
        prompt_lower = prompt.lower()
        # Extract all quoted strings
        quoted_strings = re.findall(r"'([^']*)'", prompt)
        if "vowel" in prompt_lower and quoted_strings:
            # Replace vowels with asterisks
            args["source_string"] = quoted_strings[0]
            args["regex"] = "[aeiouAEIOU]"
            args["replacement"] = "*"
    
        elif "digit" in prompt_lower and len(quoted_strings) >= 2:
            # Replace digits with a word
            args["source_string"] = quoted_strings[0]
            args["regex"] = r"\d+"
            args["replacement"] = quoted_strings[1]
    
        elif len(quoted_strings) >= 3:
            # Replace word with another word
            args["source_string"] = quoted_strings[2]
            args["regex"] = r"\b" + quoted_strings[0] + r"\b"
            args["replacement"] = quoted_strings[1]
        return args