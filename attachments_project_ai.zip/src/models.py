from pydantic import BaseModel
from typing import Dict, List, Any


class FunctionDefinition(BaseModel):
    fn_name: str
    args_names: List[str]
    args_types: Dict[str, str]
    return_type: str


class PromptTest(BaseModel):
    prompt: str


class FunctionCall(BaseModel):
    prompt: str
    fn_name: str
    args: Dict[str, Any]
